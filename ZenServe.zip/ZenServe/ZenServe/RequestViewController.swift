//
//  RequestViewController.swift
//  ZenServe
//
//  Created by Vijay Bhaskar on 19/04/16.
//  Copyright © 2016 Vijay. All rights reserved.
//

import UIKit

class RequestViewController: UIViewController,UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func submit(sender: AnyObject) {
        
        let alertView = UIAlertController(title: "Success", message: "Request Submitted Scuccessfully", preferredStyle: .Alert)
        
        let defaultAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
        alertView.addAction(defaultAction)
        
        self.presentViewController(alertView, animated: true, completion: nil)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

}
