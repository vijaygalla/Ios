//
//  LoginViewController.swift
//  ZenServe
//
//  Created by Vijay Bhaskar on 19/04/16.
//  Copyright © 2016 Vijay. All rights reserved.
//

import UIKit

extension UITextField
{
    func setBottomBorder(color:String)
    {
        self.borderStyle = UITextBorderStyle.None;
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.lightGrayColor().CGColor
        border.frame = CGRect(x: 0, y: self.frame.size.height - width,   width:  self.frame.size.width, height: self.frame.size.height)
        
        border.borderWidth = width
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }
    
}
class LoginViewController: UIViewController,UITextFieldDelegate {

   
    @IBOutlet var firstNameField: UITextField!
     @IBOutlet var lastNameField: UITextField!
    @IBOutlet var emailField: UITextField!
    @IBOutlet var passwordField: UITextField!
    @IBOutlet var zipCodeField: UITextField!
    
      override func viewDidLoad() {
        super.viewDidLoad()
        firstNameField.setBottomBorder("")
         lastNameField.setBottomBorder("")
         emailField.setBottomBorder("")
         passwordField.setBottomBorder("")
         zipCodeField.setBottomBorder("")
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(LoginViewController.keyboardWillShow(_:)), name:UIKeyboardWillShowNotification, object: nil);
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(LoginViewController.keyboardWillHide(_:)), name:UIKeyboardWillHideNotification, object: nil);
    }
    

    @IBAction func back(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self);
    }
    func keyboardWillShow(sender: NSNotification) {
        if self.view.frame.size.height<=480.0
        {self.view.frame.origin.y = -40}
    }
    
    func keyboardWillHide(sender: NSNotification) {
        self.view.frame.origin.y = 0
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func register(sender: UIButton) {
         let storyboard = UIStoryboard(name: "Main", bundle: nil)
        switch sender.tag
        {
            case 0:
                let nextView = storyboard.instantiateViewControllerWithIdentifier("LandView")
                self.navigationController?.pushViewController(nextView, animated: true)
                break
            case 1:
                let nextView = storyboard.instantiateViewControllerWithIdentifier("RegitserView") as! RegisterViewController
                nextView.isContractorType = false
                self.navigationController?.pushViewController(nextView, animated: true)
                break
            case 2:
                  let nextView = storyboard.instantiateViewControllerWithIdentifier("RegitserView") as! RegisterViewController
                  nextView.isContractorType = true
                self.navigationController?.pushViewController(nextView, animated: true)
                break
            default:
                break
            
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

