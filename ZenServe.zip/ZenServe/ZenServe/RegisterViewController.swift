//
//  RegisterViewController.swift
//  ZenServe
//
//  Created by Vijay Bhaskar on 19/04/16.
//  Copyright © 2016 Vijay. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController,UITextFieldDelegate{

    var isContractorType = Bool()
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillShow:"), name:UIKeyboardWillShowNotification, object: nil);
//        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillHide:"), name:UIKeyboardWillHideNotification, object: nil);
        
        if isContractorType == false
        {
            for iView in self.view.subviews
            {
                switch iView.tag
                {
                        case 5,6,12,13:
                                iView.hidden = true
                                break
                        default:
                                break
                }
            }
        }
    }

//    deinit {
//        NSNotificationCenter.defaultCenter().removeObserver(self);
//    }
//    func keyboardWillShow(sender: NSNotification) {
//        if self.view.frame.size.height<=480.0
//        {self.view.frame.origin.y = -40}
//    }
//    
//    func keyboardWillHide(sender: NSNotification) {
//        self.view.frame.origin.y = 0
//    }

    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
